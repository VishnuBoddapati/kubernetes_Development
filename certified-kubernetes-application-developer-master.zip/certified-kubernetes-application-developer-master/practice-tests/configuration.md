### Question 1: Resource Quota 

<details><summary>Expand The Question </summary>
<p>

Create a pod named kplabs-quota. The pod should have following configuration:

 a. Should run with nginx image.
 b. It should use maximum of 512 MiB of memory.
 c. It should use maximum of 2 core CPU.
 d. The POD should require a minimum of 128 MiB of memory before it is scheduled.
 
 </details>

