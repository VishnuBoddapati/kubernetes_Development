### Question 1: Creating Single Container Pods 

<details><summary>Expand The Question </summary>
<p>


a. Create a pod with the name of kplabs-nginx. 

b. The pod should be launched from an image of ``` mykplabs/kubernetes:nginx``` 

c. The name of the container should be mycontainer

</details>
