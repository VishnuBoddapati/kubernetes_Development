# Domain 4 - Configuration

The code mentioned in this document are used in the Certified Kubernetes Application Developer 2019 course.

https://www.udemy.com/course/mastering-certified-kubernetes-application-developer/


# Video-Document Mapper

| Sr No | Document Link |
| ------ | ------ |
| 1 | [Kubernetes Secrets][PlDa] |
| 2 | [Mounting Secrets Inside Pods][PlDb] |
| 3 | [Resource Limits][PlDc] 





   [PlDa]: <https://github.com/zealvora/certified-kubernetes-application-developer/blob/master/Domain%204%20-%20Configuration/secret-data.yaml>
   [PlDb]: <https://github.com/zealvora/certified-kubernetes-application-developer/blob/master/Domain%204%20-%20Configuration/mounting-secrets.md>
   [PlDc]: <https://github.com/zealvora/certified-kubernetes-application-developer/blob/master/Domain%204%20-%20Configuration/request-limits.yaml>

