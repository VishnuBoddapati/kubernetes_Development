# Domain 7 - Multi-Container PODS

The code mentioned in this document are used in the Certified Kubernetes Application Developer 2019 course.

https://www.udemy.com/course/mastering-certified-kubernetes-application-developer/


# Video-Document Mapper

| Sr No | Document Link |
| ------ | ------ |
| 1 | [Adapter Container][PlDa] |
| 2 | [Ambssador Container][PlDb] |




[PlDa]: <https://github.com/zealvora/certified-kubernetes-application-developer/blob/master/Domain%207%20-%20Multi-Container%20PODS/adapter.yaml>
   
[PlDb]: <https://github.com/zealvora/certified-kubernetes-application-developer/blob/master/Domain%207%20-%20Multi-Container%20PODS/ambassador.yaml>
 
 

