# Domain 4 - Observability

The code mentioned in this document are used in the Certified Kubernetes Application Developer 2019 course.

https://www.udemy.com/course/mastering-certified-kubernetes-application-developer/


# Video-Document Mapper

| Sr No | Document Link |
| ------ | ------ |
| 1 | [Liveness Probe][PlDa] |
| 2 | [Readiness Probe][PlDb] |





   [PlDa]: <https://github.com/zealvora/certified-kubernetes-application-developer/blob/master/Domain%205%20-%20Observability/livenessprobe.yaml>
   [PlDb]: <https://github.com/zealvora/certified-kubernetes-application-developer/blob/master/Domain%205%20-%20Observability/readinessprobe.yaml>

