# Domain 3 - Services and Networking

The code mentioned in this document are used in the Certified Kubernetes Application Developer 2019 course.

https://www.udemy.com/course/mastering-certified-kubernetes-application-developer/


# Video-Document Mapper

| Sr No | Document Link |
| ------ | ------ |
| 1 | [Creating our first Service and Endpoint][PlDa] |
| 2 | [Service Type: NodePort][PlDb] |
| 3 | [Network Security Policies][PlDc] 





   [PlDa]: <https://github.com/zealvora/certified-kubernetes-application-developer/blob/master/Domain%203%20-%20Services%20and%20Networking/serviceandendpoints.md>
   [PlDb]: <https://github.com/zealvora/certified-kubernetes-application-developer/blob/master/Domain%203%20-%20Services%20and%20Networking/nodeport.yaml>
   [PlDc]: <https://github.com/zealvora/certified-kubernetes-application-developer/blob/master/Domain%203%20-%20Services%20and%20Networking/nsp-deny-pod.yaml>

